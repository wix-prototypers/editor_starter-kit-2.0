//choose code source, local or cdn. used mainly for css files
const source = "cdn";
originUrl =
  source === "cdn"
    ? "https://cdn.jsdelivr.net/gh/wix-prototypers/editor_starter-kit-2.0@0.8"
    : "..";
